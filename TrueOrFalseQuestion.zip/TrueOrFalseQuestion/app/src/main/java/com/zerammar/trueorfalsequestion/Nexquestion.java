package com.zerammar.trueorfalsequestion;

import android.widget.Toast;

/**
 * Created by zerammar on 6/5/2017.
 */

public class Nexquestion {
    int numberquestion;
    boolean chick;
    public Nexquestion(int questionid , boolean chickq){
        numberquestion = questionid;
        chick = chickq ;

    }

    public int getNumberquestion() {
        return numberquestion;
    }

    public boolean getChick() {
        return chick;
    }
}
