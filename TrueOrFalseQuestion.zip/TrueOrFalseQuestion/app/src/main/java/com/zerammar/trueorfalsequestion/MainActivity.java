package com.zerammar.trueorfalsequestion;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageButton Play , Donate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Play = (ImageButton) findViewById(R.id.imageButton);
        Donate = (ImageButton) findViewById(R.id.imageButton2);
        Donate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder a = new AlertDialog.Builder(MainActivity.this);
                a.setTitle("Thanks for Support");
                a.setMessage("my paypal is : zerammarp@gmail.com");
                a.setNegativeButton("close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = a.create();
                alertDialog.show();
            }
        });
    }

    public void play(View view){
        Intent intent = new Intent(this, question.class);
        startActivity(intent);
    }

}
