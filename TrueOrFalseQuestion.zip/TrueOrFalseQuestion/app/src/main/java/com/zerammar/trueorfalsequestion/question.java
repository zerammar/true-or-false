package com.zerammar.trueorfalsequestion;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by zerammar on 6/3/2017.
 */

public class question extends Activity {
    Button tr , fl;
    TextView textView , textView2;
    ProgressBar progressBar;
    Nexquestion[] nexquestion = new Nexquestion[]{
        new Nexquestion(R.string.q1,true),
        new Nexquestion(R.string.q2,false),
        new Nexquestion(R.string.q3,true),
        new Nexquestion(R.string.q4,true),
        new Nexquestion(R.string.q5,false),
        new Nexquestion(R.string.q6,false),
        new Nexquestion(R.string.q7,true),
            new Nexquestion(R.string.q8,false),
            new Nexquestion(R.string.q9,false),
            new Nexquestion(R.string.q10,true),
            new Nexquestion(R.string.q11,false),
            new Nexquestion(R.string.q12,true),
            new Nexquestion(R.string.q13,false),
            new Nexquestion(R.string.q14,false),
            new Nexquestion(R.string.q15,true),
            new Nexquestion(R.string.q16,false),
            new Nexquestion(R.string.q17,true),
            new Nexquestion(R.string.q18,true),
            new Nexquestion(R.string.q19,true),
            new Nexquestion(R.string.q20,true)
    };
    int mquestion;
    boolean yourinsur;
    boolean k;
    int coin;
    int progressBarchang = 100 / nexquestion.length;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question);
        tr = (Button) findViewById(R.id.button);
        fl = (Button) findViewById(R.id.button2);
        textView = (TextView)findViewById(R.id.textView);
        textView2 =(TextView) findViewById(R.id.textView2);
        progressBar = (ProgressBar)findViewById(R.id.progressBar);


    }

    public void True (View view){
        k = true;
        Chickquestion();
        updatequestion();
    }




    public void False(View view){
        k = false;
        Chickquestion();
        updatequestion();
    }

    public void updatequestion(){
        mquestion = (mquestion + 1)% nexquestion.length;
        int nuperquestionid = nexquestion[mquestion].getNumberquestion();
        textView.setText(nuperquestionid);
        if(mquestion == 0){
            AlertDialog.Builder a = new AlertDialog.Builder(this);
            a.setTitle("Thanks for Support");
            a.setMessage("thanks for use app : your coin is     " + coin+" /" + nexquestion.length);
            a.setPositiveButton("Shutdown application", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            AlertDialog alertDialog = a.create();
            alertDialog.show();
        }

    }

    public void Chickquestion(){
        yourinsur = nexquestion[mquestion].getChick();
        if(yourinsur == k){

            coin ++;
            textView2.setText("your coin is "+ coin +"/ " + nexquestion.length);
            progressBar.incrementProgressBy(progressBarchang);
        }else {

        }
    }
}
